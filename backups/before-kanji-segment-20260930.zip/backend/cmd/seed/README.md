# Curriculum imports

Edit **data/catalog/curriculum.json** for JSON-backed curriculum updates. It is
the canonical schema-version-1 catalog. The older JSON files remain unchanged
as source references; the importer no longer reads them. The six beginner
sections are still defined in Go and imported through the same persistence code.

## Backup taken before this change

The topic-based curriculum cleanup is backed up in two archives at the
repository root:

- `backups/seed-before-curriculum-cleanup-20260929.zip` contains the seed source
  and catalog before the cleanup. SHA-256:
  `94968B42B9C456900F5555417D0AAB5C9FD54853141C62981E83B8AE47A00C24`.
- `backups/database-before-curriculum-cleanup-20260929.zip` contains a complete
  PostgreSQL SQL dump made immediately before the import. SHA-256:
  `80E46112AA441834F8DBB71593A32F9DA3C83D7AD68AA49F35FB0AE81E0EB6FE`.

These backups allow the source catalog and the application data to be restored
independently.

### Earlier importer backup

`backups/seed-before-improvements-20260928-202418.zip` at the repository root
contains the original 214 JSON files, seed source, models, migration code,
Dockerfile, Go dependency manifests, Compose configuration, and deployment/status
documentation. SHA-256:

`D9F72F020B98169BA13648FC5FF3CD5646735C66DD69067BC9350402A8945A1F`

This is a source backup, not a PostgreSQL dump. No application database was
modified during development. Before applying imports to an existing deployment,
take and verify a database backup using your deployment's normal procedure.

## Validate and import

From `backend/`:

```sh
go run ./cmd/seed --validate
go run ./cmd/seed --dry-run
go run ./cmd/seed --catalog ./cmd/seed/data/catalog/curriculum.json --validate
go run ./cmd/seed
```

`--validate` and `--dry-run` are equivalent offline validation commands. They
report catalog totals without connecting to the database; they do not calculate
a diff against existing database rows. Normal imports require `DATABASE_URL`.

The default catalog is embedded in the compiled seeder. Rebuild the binary or
container after editing it, or provide an external file using `--catalog`.
Working directory and build-time source paths do not affect bundled imports.

```sh
docker compose build seed
docker compose run --rm seed --validate
docker compose run --rm seed
```

Normal imports insert new records and update existing records in place. They
never delete records absent from the catalog. Catalog entries in
`retired_sections` and `retired_modules` are hidden from learners while their
database IDs and all progress/history references are retained. Bringing an ID
back into the active catalog publishes it again. Entire curriculum imports run
in one transaction, including an explicitly requested reset; failures roll
back. PostgreSQL advisory locking serializes concurrent imports. Startup schema
migration runs separately, before that transaction.

Only for an intentional destructive reset of curriculum **and learner progress**:

```sh
go run ./cmd/seed --reset --confirm-reset
```

Users and payments survive resets; study sessions, reviews, and scores do not.
Do not use resets for routine content updates.

## Editing rules

- Keep every section, module, and item `id` unchanged after first import, even
  when changing spelling, translations, titles, or ordering. IDs must be unique
  within their entity kind across the entire catalog. Assign a new unique ID to
  genuinely new content. Never reuse retired IDs.
- IDs are stored in nullable unique `seed_key` columns. The original database
  UUID is preserved, retaining progress/review references. JSON-backed identity
  does not depend on editable text or array position.
- Before the first import with keys, legacy sections/modules are matched by
  parent and title, and vocabulary by module, reading, and written form. Apply
  this baseline catalog before renaming legacy content. Ambiguous matches abort
  rather than guessing which learner history to retain. Review unmatched old
  rows manually; they are not deleted.
- Different words with the same reading, and distinct senses with separate
  item IDs, remain separate items. The old importer collapsed these by reading.
- Built-in Go content receives deterministic keys on import. Its key generation
  still depends on its original parent/text; assign explicit keys before
  renaming built-in content. JSON catalog IDs are the preferred editorial model.
- Section orders 1–6 are reserved for built-in basics. Module orders must be
  positive and unique within each section. Changing order can change the
  predecessor required for unlocking, even though stored scores survive.
- Every item has the same fields: `id`, `kanji`, `kana`, `romaji`,
  `english_meaning`, `indonesian_meaning`, `part_of_speech`, `example_sentence`,
  and `source`. A reading and at least one meaning are required. Empty optional
  strings are allowed; blank romaji is derived from kana.
- `source` records the original local dataset path. It is provenance, not proof
  of a license or editorial accuracy. Translation accuracy still needs human
  review. The importer does not invent translations.
- Unknown fields, invalid IDs, duplicate orders/IDs, invalid pass thresholds,
  missing readings/meanings, corrupted text, and database-length violations fail
  validation before any database connection.

## Conversion audit

The published catalog contains 3 JSON-backed sections, 246 topic modules, and
5,663 entries. The former Daily Vocab section and the 115 source-oriented
`Day X` / `Page X` modules are registered as retired. They remain in the
database, hidden, so existing sessions, scores, and review history keep valid
foreign keys.

Daily Vocab is now treated as source data. Its Indonesian translations are
merged into matching N3 entries, and its unique words are distributed into N3
topic modules. Raw N5, N4, and N3 page entries are likewise distributed into
stable topic modules such as Work & Business, Travel & Transport, Health &
Body, and Grammar, Adverbs & Expressions. Curated modules keep their stable IDs
and use the `Core — topic` title prefix; redistributed source material uses
`Extended — topic`.

Transitive/intransitive pairs in day files are flattened into individual entries
with distinct stable IDs and part-of-speech labels. The old loader skipped them.
One malformed N3 Christmas entry has a missing reading and replacement
characters. Its original content is preserved in `data/catalog/quarantine.json`
and in the raw source, but is excluded from new imports pending editorial review.
If it already exists in a database, it is left untouched.

`convert-legacy.cjs` documents the initial transformation and refuses to
overwrite an existing catalog. `reorganize-curriculum.cjs` documents this
topic-based publishing transformation and defaults to a dry run; pass `--write`
only when intentionally updating the canonical catalog. Do not regenerate IDs
from source positions when editing a published catalog. The unused
`data/json/kotoba` and `data/json/n5` reference datasets remain unused, as
before.

Run regression tests with `go test ./cmd/seed`. They cover full-catalog repeat
imports, legacy-ID adoption, preservation of scores/reviews, homophones, text
edits, removed source entries, validation failures, ambiguity, and rollback.
