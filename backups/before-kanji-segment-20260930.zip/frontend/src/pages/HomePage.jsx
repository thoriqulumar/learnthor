import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../lib/api';
import { ErrorBanner } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useLocale } from '../lib/locale';

function ModuleCard({ mod, sectionTitle, bypass }) {
  const { tr } = useLocale();
  const locked = mod.locked && !bypass;
  const content = <><span className="module-status" aria-hidden="true">{locked ? '×' : mod.passed ? '✓' : '↗'}</span>
    <span className="module-copy"><strong>{mod.title}</strong><small>{tr('{count} words', { count: mod.vocab_count })}{mod.high_score > 0 && ' · ' + tr('Best: {score}%', { score: mod.high_score })}</small></span></>;
  return locked ? <div className="module-tile is-locked" aria-disabled="true">{content}</div> :
    <Link className={'module-tile' + (mod.passed ? ' is-passed' : '')} to={'/modules/' + mod.id}
      state={{ title: mod.title, sectionTitle, skillScores: mod.skill_scores ?? {} }}>{content}</Link>;
}

export default function HomePage() {
  const { user, refreshUser } = useAuth();
  const { tr, language } = useLocale();
  const privileged = ['admin', 'editor'].includes(user?.role);
  const premium = privileged || user?.subscription_tier === 'premium';
  const bypass = privileged || (premium && user?.progression_bypass === true);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reviewStats, setReviewStats] = useState(null);
  const [glossSaving, setGlossSaving] = useState(false);
  const [preferenceError, setPreferenceError] = useState(null);
  const gloss = user?.preferred_gloss ?? 'both';
  useEffect(() => {
    api.get('/sections').then(({ data }) => setSections(data.sections ?? []))
      .catch(setError).finally(() => setLoading(false));
    api.get('/reviews/stats').then(({ data }) => setReviewStats(data)).catch(() => {});
  }, []);
  function updateGloss(next) {
    if (next === gloss || glossSaving) return;
    setGlossSaving(true); setPreferenceError(null);
    api.put('/me/preferences', { preferred_gloss: next })
      .then(() => refreshUser({ preferred_gloss: next }))
      .catch(setPreferenceError).finally(() => setGlossSaving(false));
  }
  if (loading) return <div className="page-loader" role="status" aria-label={tr('Loading…')}><span /></div>;
  if (error) return <div className="page-panel"><ErrorBanner err={error} lang={language} onRetry={() => window.location.reload()} /></div>;
  const effective = sections.map((s, i) => ({ ...s,
    premiumLocked: s.is_premium && !premium,
    locked: !bypass && (s.locked || (s.is_premium && !premium) || (i > 0 && (sections[i - 1].mastery_pct ?? 0) < 100)),
  }));
  const total = sections.reduce((n, s) => n + s.modules_total, 0);
  const passed = sections.reduce((n, s) => n + s.modules_passed, 0);
  const nextSection = effective.find(s => !s.locked && s.modules?.some(m => !m.passed && (!m.locked || bypass)));
  const next = nextSection?.modules.find(m => !m.passed && (!m.locked || bypass));
  return <div className="dashboard">
    <header className="study-hero">
      <div className="hero-copy"><p className="eyebrow">LEARNTHOR / 日本語</p><h1>{tr('Make Japanese yours.')}</h1>
        <p className="hero-description">{tr('A new word. A new possibility.')}</p>
        {next && <Link className="hero-cta" to={'/modules/' + next.id} state={{ title: next.title, sectionTitle: nextSection.title, skillScores: next.skill_scores }}>{tr('Continue learning')} <span>↗</span></Link>}
      </div>
      <div className="hero-art" aria-hidden="true"><span className="art-star">✦</span><span className="art-kanji">学</span><span className="art-sticker">LEVEL UP!</span></div>
    </header>
    <div className="dashboard-strip">
      <div><span className="strip-label">{tr('Learning progress')}</span><strong>{passed}<span> / {total}</span></strong><small>{tr('modules')}</small></div>
      <div className="gloss-control"><label htmlFor="gloss">{tr('Vocabulary language')}</label><select id="gloss" value={gloss} onChange={e => updateGloss(e.target.value)} disabled={glossSaving}>
        <option value="en">English</option><option value="id">Bahasa Indonesia</option><option value="both">EN + ID</option>
      </select></div>
    </div>
    {preferenceError && <ErrorBanner err={preferenceError} lang={language} />}
    {user?.progression_bypass && premium && <p className="personal-notice"><strong>★ {tr('Personal access')}</strong> {tr('All lessons available. Your scores still reflect your practice.')}</p>}
    {reviewStats?.due > 0 && <Link to="/review" className="review-banner"><div><span className="eyebrow">{tr('Your next move')}</span><h2>{tr('Daily Review')}</h2><p>{tr('{count} cards due', { count: reviewStats.due })}</p></div><span aria-hidden="true">↗</span></Link>}
    {!premium && <Link to="/upgrade" className="upgrade-banner"><strong>{tr('👑 Upgrade to Premium')}</strong><span>{tr('Unlock N4, N3 & Daily Vocab — one-time payment, lifetime access')} ↗</span></Link>}
    <div className="route-heading"><h2>{tr('Your learning route')}</h2><span>01 — {String(sections.length).padStart(2, '0')}</span></div>
    <div className="section-list">{effective.map((section, index) => <section key={section.id} className={'course-section' + (section.locked ? ' section-locked' : '')}>
      <div className="section-heading"><span className="section-number">{String(index + 1).padStart(2, '0')}</span><div><p className="section-kicker">{section.is_premium ? 'PREMIUM' : 'FOUNDATION'}</p><h3>{section.title}</h3></div><span className="section-score">{section.mastery_pct}%</span></div>
      <div className="section-meter"><span style={{ width: section.mastery_pct + '%' }} /></div>
      {section.locked ? <div className="section-lock-message"><strong>{tr(section.premiumLocked ? 'Premium section' : 'Locked')}</strong><p>{tr(section.premiumLocked ? 'Premium includes the content. Learning prerequisites still apply.' : 'Master the previous section to unlock')}</p>{section.premiumLocked && <Link to="/upgrade">{tr('Upgrade to Premium →')}</Link>}</div> : null}
      <div className="module-grid">{(section.modules ?? []).map(mod => <ModuleCard key={mod.id} mod={{ ...mod, locked: section.locked || mod.locked }} sectionTitle={section.title} bypass={bypass} />)}</div>
      {!section.locked && (section.mastery_pct === 100 || bypass) && section.modules_total > 0 && <Link className="section-test" to={'/sections/' + section.id + '/quiz'} state={{ sectionTitle: section.title }}>{tr('Section Test')} <span>↗</span></Link>}
    </section>)}</div>
  </div>;
}
