package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"

	"github.com/google/uuid"
	"github.com/joho/godotenv"
	"github.com/learnthor/backend/db"
	"github.com/learnthor/backend/models"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Println("no .env file, reading from system environment")
	}

	database, err := db.Connect()
	if err != nil {
		log.Fatalf("db connect: %v", err)
	}
	if err := db.Migrate(database); err != nil {
		log.Fatalf("migrate: %v", err)
	}

	if len(os.Args) > 1 && os.Args[1] == "--reset" {
		if err := resetCurriculum(database); err != nil {
			log.Fatalf("reset: %v", err)
		}
		log.Println("✓ curriculum tables truncated (users preserved)")
	}

	seed(database)
	log.Println("✓ seed complete")
}

// resetCurriculum deletes all curriculum and progress rows while keeping
// the users table intact. Tables are truncated in dependency order to
// satisfy foreign-key constraints.
func resetCurriculum(db *gorm.DB) error {
	tables := []string{
		"srs_reviews",
		"session_items",
		"study_sessions",
		"module_skill_progress",
		"module_progress",
		"section_progress",
		"vocab_items",
		"modules",
		"sections",
		"courses",
	}
	for _, t := range tables {
		if err := db.Exec("TRUNCATE TABLE " + t + " RESTART IDENTITY CASCADE").Error; err != nil {
			return fmt.Errorf("truncate %s: %w", t, err)
		}
	}
	return nil
}

// strPtr converts a string literal to *string (for nullable Kanji field).
func strPtr(s string) *string { return &s }

// ─────────────────────────────────────────────────────────────────────────────
// Seed entry point
// ─────────────────────────────────────────────────────────────────────────────

func seed(db *gorm.DB) {
	course := upsertCourse(db, models.Course{
		Title:       "JLPT N5 Masterclass",
		Description: "Complete preparation for the JLPT N5 exam. Covers hiragana, katakana, essential vocabulary, basic kanji, and foundational grammar.",
		SortOrder:   1,
	})

	seedHiragana(db, course)
	seedKatakana(db, course)
	seedGreetings(db, course)
	seedNumbers(db, course)
	seedBasicVocabulary(db, course)
	seedBasicKanji(db, course)
	seedKotobaFromJSON(db, course)
	seedPagedVocab(db, course)
	seedDayFiles(db, course)

	// Back-fill kanji = romaji for all character items so the quiz can show
	// "a → pick あ" instead of "あ → pick あ" (which is pointless).
	if err := db.Exec(
		"UPDATE vocab_items SET kanji = romaji WHERE part_of_speech = 'character' AND (kanji IS NULL OR kanji = '')",
	).Error; err != nil {
		log.Printf("warn: fixCharacterKanji: %v", err)
	} else {
		log.Println("  ✓ character kanji back-filled from romaji")
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 1 — Hiragana
// ─────────────────────────────────────────────────────────────────────────────

func seedHiragana(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Hiragana", SortOrder: 1})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Vowels (あいうえお)", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{nil, "あ", "a", "The letter 'a'", "character", ""},
		{nil, "い", "i", "The letter 'i'", "character", ""},
		{nil, "う", "u", "The letter 'u'", "character", ""},
		{nil, "え", "e", "The letter 'e'", "character", ""},
		{nil, "お", "o", "The letter 'o'", "character", ""},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "K-row (かきくけこ)", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{nil, "か", "ka", "The letter 'ka'", "character", ""},
		{nil, "き", "ki", "The letter 'ki'", "character", ""},
		{nil, "く", "ku", "The letter 'ku'", "character", ""},
		{nil, "け", "ke", "The letter 'ke'", "character", ""},
		{nil, "こ", "ko", "The letter 'ko'", "character", ""},
	})

	m3 := upsertModule(database, sec.ID, models.Module{Title: "S-row (さしすせそ)", SortOrder: 3, PassThreshold: 90})
	upsertVocabItems(database, m3.ID, []vocabSeed{
		{nil, "さ", "sa", "The letter 'sa'", "character", ""},
		{nil, "し", "shi", "The letter 'shi'", "character", ""},
		{nil, "す", "su", "The letter 'su'", "character", ""},
		{nil, "せ", "se", "The letter 'se'", "character", ""},
		{nil, "そ", "so", "The letter 'so'", "character", ""},
	})

	m4 := upsertModule(database, sec.ID, models.Module{Title: "T-row (たちつてと)", SortOrder: 4, PassThreshold: 90})
	upsertVocabItems(database, m4.ID, []vocabSeed{
		{nil, "た", "ta", "The letter 'ta'", "character", ""},
		{nil, "ち", "chi", "The letter 'chi'", "character", ""},
		{nil, "つ", "tsu", "The letter 'tsu'", "character", ""},
		{nil, "て", "te", "The letter 'te'", "character", ""},
		{nil, "と", "to", "The letter 'to'", "character", ""},
	})

	m5 := upsertModule(database, sec.ID, models.Module{Title: "N & M rows (なにぬねの・まみむめも)", SortOrder: 5, PassThreshold: 90})
	upsertVocabItems(database, m5.ID, []vocabSeed{
		{nil, "な", "na", "The letter 'na'", "character", ""},
		{nil, "に", "ni", "The letter 'ni'", "character", ""},
		{nil, "ぬ", "nu", "The letter 'nu'", "character", ""},
		{nil, "ね", "ne", "The letter 'ne'", "character", ""},
		{nil, "の", "no", "The letter 'no'", "character", ""},
		{nil, "ま", "ma", "The letter 'ma'", "character", ""},
		{nil, "み", "mi", "The letter 'mi'", "character", ""},
		{nil, "む", "mu", "The letter 'mu'", "character", ""},
		{nil, "め", "me", "The letter 'me'", "character", ""},
		{nil, "も", "mo", "The letter 'mo'", "character", ""},
	})

	m6 := upsertModule(database, sec.ID, models.Module{Title: "H-row (はひふへほ)", SortOrder: 6, PassThreshold: 90})
	upsertVocabItems(database, m6.ID, []vocabSeed{
		{nil, "は", "ha", "The letter 'ha'", "character", ""},
		{nil, "ひ", "hi", "The letter 'hi'", "character", ""},
		{nil, "ふ", "fu", "The letter 'fu'", "character", ""},
		{nil, "へ", "he", "The letter 'he'", "character", ""},
		{nil, "ほ", "ho", "The letter 'ho'", "character", ""},
	})

	m7 := upsertModule(database, sec.ID, models.Module{Title: "Y & R rows (やゆよ・らりるれろ)", SortOrder: 7, PassThreshold: 90})
	upsertVocabItems(database, m7.ID, []vocabSeed{
		{nil, "や", "ya", "The letter 'ya'", "character", ""},
		{nil, "ゆ", "yu", "The letter 'yu'", "character", ""},
		{nil, "よ", "yo", "The letter 'yo'", "character", ""},
		{nil, "ら", "ra", "The letter 'ra'", "character", ""},
		{nil, "り", "ri", "The letter 'ri'", "character", ""},
		{nil, "る", "ru", "The letter 'ru'", "character", ""},
		{nil, "れ", "re", "The letter 're'", "character", ""},
		{nil, "ろ", "ro", "The letter 'ro'", "character", ""},
	})

	m8 := upsertModule(database, sec.ID, models.Module{Title: "W-row & N (わをん)", SortOrder: 8, PassThreshold: 90})
	upsertVocabItems(database, m8.ID, []vocabSeed{
		{nil, "わ", "wa", "The letter 'wa'", "character", ""},
		{nil, "を", "wo", "The particle 'wo/o'", "character", ""},
		{nil, "ん", "n", "The letter 'n'", "character", ""},
	})

	m9 := upsertModule(database, sec.ID, models.Module{Title: "Voiced Sounds — Dakuten (が・ざ・だ・ば rows)", SortOrder: 9, PassThreshold: 90})
	upsertVocabItems(database, m9.ID, []vocabSeed{
		{nil, "が", "ga", "The letter 'ga'", "character", ""},
		{nil, "ぎ", "gi", "The letter 'gi'", "character", ""},
		{nil, "ぐ", "gu", "The letter 'gu'", "character", ""},
		{nil, "げ", "ge", "The letter 'ge'", "character", ""},
		{nil, "ご", "go", "The letter 'go'", "character", ""},
		{nil, "ざ", "za", "The letter 'za'", "character", ""},
		{nil, "じ", "ji", "The letter 'ji'", "character", ""},
		{nil, "ず", "zu", "The letter 'zu'", "character", ""},
		{nil, "ぜ", "ze", "The letter 'ze'", "character", ""},
		{nil, "ぞ", "zo", "The letter 'zo'", "character", ""},
		{nil, "だ", "da", "The letter 'da'", "character", ""},
		{nil, "で", "de", "The letter 'de'", "character", ""},
		{nil, "ど", "do", "The letter 'do'", "character", ""},
		{nil, "ば", "ba", "The letter 'ba'", "character", ""},
		{nil, "び", "bi", "The letter 'bi'", "character", ""},
		{nil, "ぶ", "bu", "The letter 'bu'", "character", ""},
		{nil, "べ", "be", "The letter 'be'", "character", ""},
		{nil, "ぼ", "bo", "The letter 'bo'", "character", ""},
	})

	m10 := upsertModule(database, sec.ID, models.Module{Title: "Semi-voiced — Handakuten (ぱぴぷぺぽ)", SortOrder: 10, PassThreshold: 90})
	upsertVocabItems(database, m10.ID, []vocabSeed{
		{nil, "ぱ", "pa", "The letter 'pa'", "character", ""},
		{nil, "ぴ", "pi", "The letter 'pi'", "character", ""},
		{nil, "ぷ", "pu", "The letter 'pu'", "character", ""},
		{nil, "ぺ", "pe", "The letter 'pe'", "character", ""},
		{nil, "ぽ", "po", "The letter 'po'", "character", ""},
	})

	m11 := upsertModule(database, sec.ID, models.Module{Title: "Combination Sounds (きゃ・しゃ・ちゃ etc.)", SortOrder: 11, PassThreshold: 90})
	upsertVocabItems(database, m11.ID, []vocabSeed{
		{nil, "きゃ", "kya", "Combination 'kya'", "character", ""},
		{nil, "きゅ", "kyu", "Combination 'kyu'", "character", ""},
		{nil, "きょ", "kyo", "Combination 'kyo'", "character", ""},
		{nil, "しゃ", "sha", "Combination 'sha'", "character", ""},
		{nil, "しゅ", "shu", "Combination 'shu'", "character", ""},
		{nil, "しょ", "sho", "Combination 'sho'", "character", ""},
		{nil, "ちゃ", "cha", "Combination 'cha'", "character", ""},
		{nil, "ちゅ", "chu", "Combination 'chu'", "character", ""},
		{nil, "ちょ", "cho", "Combination 'cho'", "character", ""},
		{nil, "にゃ", "nya", "Combination 'nya'", "character", ""},
		{nil, "にゅ", "nyu", "Combination 'nyu'", "character", ""},
		{nil, "にょ", "nyo", "Combination 'nyo'", "character", ""},
		{nil, "ひゃ", "hya", "Combination 'hya'", "character", ""},
		{nil, "ひゅ", "hyu", "Combination 'hyu'", "character", ""},
		{nil, "ひょ", "hyo", "Combination 'hyo'", "character", ""},
		{nil, "みゃ", "mya", "Combination 'mya'", "character", ""},
		{nil, "みゅ", "myu", "Combination 'myu'", "character", ""},
		{nil, "みょ", "myo", "Combination 'myo'", "character", ""},
		{nil, "りゃ", "rya", "Combination 'rya'", "character", ""},
		{nil, "りゅ", "ryu", "Combination 'ryu'", "character", ""},
		{nil, "りょ", "ryo", "Combination 'ryo'", "character", ""},
		{nil, "ぎゃ", "gya", "Combination 'gya'", "character", ""},
		{nil, "ぎゅ", "gyu", "Combination 'gyu'", "character", ""},
		{nil, "ぎょ", "gyo", "Combination 'gyo'", "character", ""},
		{nil, "じゃ", "ja", "Combination 'ja'", "character", ""},
		{nil, "じゅ", "ju", "Combination 'ju'", "character", ""},
		{nil, "じょ", "jo", "Combination 'jo'", "character", ""},
		{nil, "びゃ", "bya", "Combination 'bya'", "character", ""},
		{nil, "びゅ", "byu", "Combination 'byu'", "character", ""},
		{nil, "びょ", "byo", "Combination 'byo'", "character", ""},
		{nil, "ぴゃ", "pya", "Combination 'pya'", "character", ""},
		{nil, "ぴゅ", "pyu", "Combination 'pyu'", "character", ""},
		{nil, "ぴょ", "pyo", "Combination 'pyo'", "character", ""},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 2 — Katakana
// ─────────────────────────────────────────────────────────────────────────────

func seedKatakana(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Katakana", SortOrder: 2})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Vowels (アイウエオ)", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{nil, "ア", "a", "The letter 'a'", "character", ""},
		{nil, "イ", "i", "The letter 'i'", "character", ""},
		{nil, "ウ", "u", "The letter 'u'", "character", ""},
		{nil, "エ", "e", "The letter 'e'", "character", ""},
		{nil, "オ", "o", "The letter 'o'", "character", ""},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "K-row (カキクケコ)", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{nil, "カ", "ka", "The letter 'ka'", "character", ""},
		{nil, "キ", "ki", "The letter 'ki'", "character", ""},
		{nil, "ク", "ku", "The letter 'ku'", "character", ""},
		{nil, "ケ", "ke", "The letter 'ke'", "character", ""},
		{nil, "コ", "ko", "The letter 'ko'", "character", ""},
	})

	m3 := upsertModule(database, sec.ID, models.Module{Title: "S-row (サシスセソ)", SortOrder: 3, PassThreshold: 90})
	upsertVocabItems(database, m3.ID, []vocabSeed{
		{nil, "サ", "sa", "The letter 'sa'", "character", ""},
		{nil, "シ", "shi", "The letter 'shi'", "character", ""},
		{nil, "ス", "su", "The letter 'su'", "character", ""},
		{nil, "セ", "se", "The letter 'se'", "character", ""},
		{nil, "ソ", "so", "The letter 'so'", "character", ""},
	})

	m4 := upsertModule(database, sec.ID, models.Module{Title: "T-row (タチツテト)", SortOrder: 4, PassThreshold: 90})
	upsertVocabItems(database, m4.ID, []vocabSeed{
		{nil, "タ", "ta", "The letter 'ta'", "character", ""},
		{nil, "チ", "chi", "The letter 'chi'", "character", ""},
		{nil, "ツ", "tsu", "The letter 'tsu'", "character", ""},
		{nil, "テ", "te", "The letter 'te'", "character", ""},
		{nil, "ト", "to", "The letter 'to'", "character", ""},
	})

	m5 := upsertModule(database, sec.ID, models.Module{Title: "N & M rows (ナニヌネノ・マミムメモ)", SortOrder: 5, PassThreshold: 90})
	upsertVocabItems(database, m5.ID, []vocabSeed{
		{nil, "ナ", "na", "The letter 'na'", "character", ""},
		{nil, "ニ", "ni", "The letter 'ni'", "character", ""},
		{nil, "ヌ", "nu", "The letter 'nu'", "character", ""},
		{nil, "ネ", "ne", "The letter 'ne'", "character", ""},
		{nil, "ノ", "no", "The letter 'no'", "character", ""},
		{nil, "マ", "ma", "The letter 'ma'", "character", ""},
		{nil, "ミ", "mi", "The letter 'mi'", "character", ""},
		{nil, "ム", "mu", "The letter 'mu'", "character", ""},
		{nil, "メ", "me", "The letter 'me'", "character", ""},
		{nil, "モ", "mo", "The letter 'mo'", "character", ""},
	})

	m6 := upsertModule(database, sec.ID, models.Module{Title: "H-row (ハヒフヘホ)", SortOrder: 6, PassThreshold: 90})
	upsertVocabItems(database, m6.ID, []vocabSeed{
		{nil, "ハ", "ha", "The letter 'ha'", "character", ""},
		{nil, "ヒ", "hi", "The letter 'hi'", "character", ""},
		{nil, "フ", "fu", "The letter 'fu'", "character", ""},
		{nil, "ヘ", "he", "The letter 'he'", "character", ""},
		{nil, "ホ", "ho", "The letter 'ho'", "character", ""},
	})

	m7 := upsertModule(database, sec.ID, models.Module{Title: "Y & R rows (ヤユヨ・ラリルレロ)", SortOrder: 7, PassThreshold: 90})
	upsertVocabItems(database, m7.ID, []vocabSeed{
		{nil, "ヤ", "ya", "The letter 'ya'", "character", ""},
		{nil, "ユ", "yu", "The letter 'yu'", "character", ""},
		{nil, "ヨ", "yo", "The letter 'yo'", "character", ""},
		{nil, "ラ", "ra", "The letter 'ra'", "character", ""},
		{nil, "リ", "ri", "The letter 'ri'", "character", ""},
		{nil, "ル", "ru", "The letter 'ru'", "character", ""},
		{nil, "レ", "re", "The letter 're'", "character", ""},
		{nil, "ロ", "ro", "The letter 'ro'", "character", ""},
	})

	m8 := upsertModule(database, sec.ID, models.Module{Title: "W-row & N (ワヲン)", SortOrder: 8, PassThreshold: 90})
	upsertVocabItems(database, m8.ID, []vocabSeed{
		{nil, "ワ", "wa", "The letter 'wa'", "character", ""},
		{nil, "ヲ", "wo", "The particle 'wo/o'", "character", ""},
		{nil, "ン", "n", "The letter 'n'", "character", ""},
	})

	m9 := upsertModule(database, sec.ID, models.Module{Title: "Voiced Sounds — Dakuten (ガ・ザ・ダ・バ rows)", SortOrder: 9, PassThreshold: 90})
	upsertVocabItems(database, m9.ID, []vocabSeed{
		{nil, "ガ", "ga", "The letter 'ga'", "character", ""},
		{nil, "ギ", "gi", "The letter 'gi'", "character", ""},
		{nil, "グ", "gu", "The letter 'gu'", "character", ""},
		{nil, "ゲ", "ge", "The letter 'ge'", "character", ""},
		{nil, "ゴ", "go", "The letter 'go'", "character", ""},
		{nil, "ザ", "za", "The letter 'za'", "character", ""},
		{nil, "ジ", "ji", "The letter 'ji'", "character", ""},
		{nil, "ズ", "zu", "The letter 'zu'", "character", ""},
		{nil, "ゼ", "ze", "The letter 'ze'", "character", ""},
		{nil, "ゾ", "zo", "The letter 'zo'", "character", ""},
		{nil, "ダ", "da", "The letter 'da'", "character", ""},
		{nil, "デ", "de", "The letter 'de'", "character", ""},
		{nil, "ド", "do", "The letter 'do'", "character", ""},
		{nil, "バ", "ba", "The letter 'ba'", "character", ""},
		{nil, "ビ", "bi", "The letter 'bi'", "character", ""},
		{nil, "ブ", "bu", "The letter 'bu'", "character", ""},
		{nil, "ベ", "be", "The letter 'be'", "character", ""},
		{nil, "ボ", "bo", "The letter 'bo'", "character", ""},
	})

	m10 := upsertModule(database, sec.ID, models.Module{Title: "Semi-voiced — Handakuten (パピプペポ)", SortOrder: 10, PassThreshold: 90})
	upsertVocabItems(database, m10.ID, []vocabSeed{
		{nil, "パ", "pa", "The letter 'pa'", "character", ""},
		{nil, "ピ", "pi", "The letter 'pi'", "character", ""},
		{nil, "プ", "pu", "The letter 'pu'", "character", ""},
		{nil, "ペ", "pe", "The letter 'pe'", "character", ""},
		{nil, "ポ", "po", "The letter 'po'", "character", ""},
	})

	m11 := upsertModule(database, sec.ID, models.Module{Title: "Combination Sounds (キャ・シャ・チャ etc.)", SortOrder: 11, PassThreshold: 90})
	upsertVocabItems(database, m11.ID, []vocabSeed{
		{nil, "キャ", "kya", "Combination 'kya'", "character", ""},
		{nil, "キュ", "kyu", "Combination 'kyu'", "character", ""},
		{nil, "キョ", "kyo", "Combination 'kyo'", "character", ""},
		{nil, "シャ", "sha", "Combination 'sha'", "character", ""},
		{nil, "シュ", "shu", "Combination 'shu'", "character", ""},
		{nil, "ショ", "sho", "Combination 'sho'", "character", ""},
		{nil, "チャ", "cha", "Combination 'cha'", "character", ""},
		{nil, "チュ", "chu", "Combination 'chu'", "character", ""},
		{nil, "チョ", "cho", "Combination 'cho'", "character", ""},
		{nil, "ニャ", "nya", "Combination 'nya'", "character", ""},
		{nil, "ニュ", "nyu", "Combination 'nyu'", "character", ""},
		{nil, "ニョ", "nyo", "Combination 'nyo'", "character", ""},
		{nil, "ヒャ", "hya", "Combination 'hya'", "character", ""},
		{nil, "ヒュ", "hyu", "Combination 'hyu'", "character", ""},
		{nil, "ヒョ", "hyo", "Combination 'hyo'", "character", ""},
		{nil, "ミャ", "mya", "Combination 'mya'", "character", ""},
		{nil, "ミュ", "myu", "Combination 'myu'", "character", ""},
		{nil, "ミョ", "myo", "Combination 'myo'", "character", ""},
		{nil, "リャ", "rya", "Combination 'rya'", "character", ""},
		{nil, "リュ", "ryu", "Combination 'ryu'", "character", ""},
		{nil, "リョ", "ryo", "Combination 'ryo'", "character", ""},
		{nil, "ギャ", "gya", "Combination 'gya'", "character", ""},
		{nil, "ギュ", "gyu", "Combination 'gyu'", "character", ""},
		{nil, "ギョ", "gyo", "Combination 'gyo'", "character", ""},
		{nil, "ジャ", "ja", "Combination 'ja'", "character", ""},
		{nil, "ジュ", "ju", "Combination 'ju'", "character", ""},
		{nil, "ジョ", "jo", "Combination 'jo'", "character", ""},
		{nil, "ビャ", "bya", "Combination 'bya'", "character", ""},
		{nil, "ビュ", "byu", "Combination 'byu'", "character", ""},
		{nil, "ビョ", "byo", "Combination 'byo'", "character", ""},
		{nil, "ピャ", "pya", "Combination 'pya'", "character", ""},
		{nil, "ピュ", "pyu", "Combination 'pyu'", "character", ""},
		{nil, "ピョ", "pyo", "Combination 'pyo'", "character", ""},
	})

	m12 := upsertModule(database, sec.ID, models.Module{Title: "Loanword Special Sounds (ファ・ティ・ウィ etc.)", SortOrder: 12, PassThreshold: 90})
	upsertVocabItems(database, m12.ID, []vocabSeed{
		{nil, "ファ", "fa", "Loanword sound 'fa' (e.g. ファン fan)", "character", ""},
		{nil, "フィ", "fi", "Loanword sound 'fi' (e.g. フィルム film)", "character", ""},
		{nil, "フェ", "fe", "Loanword sound 'fe' (e.g. フェスティバル festival)", "character", ""},
		{nil, "フォ", "fo", "Loanword sound 'fo' (e.g. フォーク fork)", "character", ""},
		{nil, "ティ", "ti", "Loanword sound 'ti' (e.g. パーティー party)", "character", ""},
		{nil, "ディ", "di", "Loanword sound 'di' (e.g. ディスコ disco)", "character", ""},
		{nil, "ウィ", "wi", "Loanword sound 'wi' (e.g. ウィスキー whisky)", "character", ""},
		{nil, "ウェ", "we", "Loanword sound 'we' (e.g. ウェブ web)", "character", ""},
		{nil, "ウォ", "wo2", "Loanword sound 'wo' (e.g. ウォーター water)", "character", ""},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 3 — Basic Greetings & Expressions
// ─────────────────────────────────────────────────────────────────────────────

func seedGreetings(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Basic Greetings & Expressions", SortOrder: 3})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Daily Greetings", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{nil, "おはよう", "ohayou", "Good morning (casual)", "expression", "おはよう！"},
		{nil, "おはようございます", "ohayou gozaimasu", "Good morning (formal)", "expression", "おはようございます、せんせい。"},
		{nil, "こんにちは", "konnichiwa", "Hello / Good afternoon", "expression", "こんにちは、おげんきですか？"},
		{nil, "こんばんは", "konbanwa", "Good evening", "expression", "こんばんは！"},
		{nil, "おやすみなさい", "oyasuminasai", "Good night", "expression", "おやすみなさい。"},
		{nil, "さようなら", "sayounara", "Goodbye", "expression", "さようなら、またね。"},
		{nil, "ありがとうございます", "arigatou gozaimasu", "Thank you (formal)", "expression", "ありがとうございます！"},
		{nil, "すみません", "sumimasen", "Excuse me / I'm sorry", "expression", "すみません、トイレはどこですか？"},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "Introductions", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{nil, "はじめまして", "hajimemashite", "Nice to meet you", "expression", "はじめまして、たなかです。"},
		{nil, "どうぞよろしく", "douzo yoroshiku", "Please be kind to me", "expression", "どうぞよろしくおねがいします。"},
		{nil, "わたし", "watashi", "I / Me", "pronoun", "わたしはがくせいです。"},
		{nil, "なまえ", "namae", "Name", "noun", "なまえはなんですか？"},
		{nil, "にほんご", "nihongo", "Japanese language", "noun", "にほんごをべんきょうします。"},
		{nil, "えいご", "eigo", "English language", "noun", "えいごがはなせます。"},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 3 — Numbers & Time
// ─────────────────────────────────────────────────────────────────────────────

func seedNumbers(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Numbers & Time", SortOrder: 4})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Numbers 1–10", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{strPtr("一"), "いち", "ichi", "One", "number", "いちにさん…"},
		{strPtr("二"), "に", "ni", "Two", "number", ""},
		{strPtr("三"), "さん", "san", "Three", "number", ""},
		{strPtr("四"), "し・よん", "shi / yon", "Four", "number", ""},
		{strPtr("五"), "ご", "go", "Five", "number", ""},
		{strPtr("六"), "ろく", "roku", "Six", "number", ""},
		{strPtr("七"), "しち・なな", "shichi / nana", "Seven", "number", ""},
		{strPtr("八"), "はち", "hachi", "Eight", "number", ""},
		{strPtr("九"), "く・きゅう", "ku / kyuu", "Nine", "number", ""},
		{strPtr("十"), "じゅう", "juu", "Ten", "number", "じゅうえんです。"},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "Days of the Week", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{strPtr("月曜日"), "げつようび", "getsuyoubi", "Monday", "noun", "げつようびにがっこうへいきます。"},
		{strPtr("火曜日"), "かようび", "kayoubi", "Tuesday", "noun", ""},
		{strPtr("水曜日"), "すいようび", "suiyoubi", "Wednesday", "noun", ""},
		{strPtr("木曜日"), "もくようび", "mokuyoubi", "Thursday", "noun", ""},
		{strPtr("金曜日"), "きんようび", "kinyoubi", "Friday", "noun", "きんようびがすきです。"},
		{strPtr("土曜日"), "どようび", "doyoubi", "Saturday", "noun", ""},
		{strPtr("日曜日"), "にちようび", "nichiyoubi", "Sunday", "noun", "にちようびはやすみです。"},
	})

	m3 := upsertModule(database, sec.ID, models.Module{Title: "Time Expressions", SortOrder: 3, PassThreshold: 90})
	upsertVocabItems(database, m3.ID, []vocabSeed{
		{strPtr("今"), "いま", "ima", "Now", "noun", "いまなんじですか？"},
		{strPtr("今日"), "きょう", "kyou", "Today", "noun", "きょうはいいてんきです。"},
		{strPtr("明日"), "あした", "ashita", "Tomorrow", "noun", "あしたがっこうがあります。"},
		{strPtr("昨日"), "きのう", "kinou", "Yesterday", "noun", "きのうえいがをみました。"},
		{strPtr("朝"), "あさ", "asa", "Morning", "noun", "あさごはんをたべます。"},
		{strPtr("昼"), "ひる", "hiru", "Noon / Daytime", "noun", "ひるごはんはなんですか？"},
		{strPtr("夜"), "よる", "yoru", "Night / Evening", "noun", "よるべんきょうします。"},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 4 — Basic Vocabulary
// ─────────────────────────────────────────────────────────────────────────────

func seedBasicVocabulary(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Basic Vocabulary", SortOrder: 5})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Family Members", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{strPtr("家族"), "かぞく", "kazoku", "Family", "noun", "わたしのかぞくはよにんです。"},
		{strPtr("父"), "ちち", "chichi", "My father", "noun", "ちちはいしゃです。"},
		{strPtr("母"), "はは", "haha", "My mother", "noun", "はははせんせいです。"},
		{strPtr("お父さん"), "おとうさん", "otousan", "Father (someone else's)", "noun", "おとうさんはどこですか？"},
		{strPtr("お母さん"), "おかあさん", "okaasan", "Mother (someone else's)", "noun", ""},
		{strPtr("兄"), "あに", "ani", "My older brother", "noun", ""},
		{strPtr("姉"), "あね", "ane", "My older sister", "noun", ""},
		{strPtr("弟"), "おとうと", "otouto", "Younger brother", "noun", ""},
		{strPtr("妹"), "いもうと", "imouto", "Younger sister", "noun", ""},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "Food & Drink", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{strPtr("御飯"), "ごはん", "gohan", "Rice / Meal", "noun", "ごはんをたべます。"},
		{strPtr("水"), "みず", "mizu", "Water", "noun", "みずをのみます。"},
		{nil, "おちゃ", "ocha", "Green tea", "noun", "おちゃがすきです。"},
		{nil, "パン", "pan", "Bread", "noun", "あさパンをたべます。"},
		{strPtr("卵"), "たまご", "tamago", "Egg", "noun", "たまごりょうりがすきです。"},
		{strPtr("魚"), "さかな", "sakana", "Fish", "noun", "さかなをたべます。"},
		{strPtr("肉"), "にく", "niku", "Meat", "noun", "にくがすきです。"},
		{strPtr("野菜"), "やさい", "yasai", "Vegetables", "noun", "やさいはからだにいいです。"},
		{strPtr("果物"), "くだもの", "kudamono", "Fruit", "noun", "くだものをまいにちたべます。"},
		{strPtr("お酒"), "おさけ", "osake", "Alcohol / Japanese sake", "noun", "おさけはのみません。"},
	})

	m3 := upsertModule(database, sec.ID, models.Module{Title: "Colors", SortOrder: 3, PassThreshold: 90})
	upsertVocabItems(database, m3.ID, []vocabSeed{
		{strPtr("赤"), "あか", "aka", "Red", "noun/adjective", "あかいくるまです。"},
		{strPtr("青"), "あお", "ao", "Blue / Green", "noun/adjective", "そらはあおいです。"},
		{strPtr("白"), "しろ", "shiro", "White", "noun/adjective", "しろいねこがいます。"},
		{strPtr("黒"), "くろ", "kuro", "Black", "noun/adjective", "くろいかばんをもっています。"},
		{strPtr("黄色"), "きいろ", "kiiro", "Yellow", "noun/adjective", "きいろいはなです。"},
		{nil, "みどり", "midori", "Green", "noun/adjective", "みどりがすきです。"},
	})

	m4 := upsertModule(database, sec.ID, models.Module{Title: "Verbs: Daily Actions", SortOrder: 4, PassThreshold: 90})
	upsertVocabItems(database, m4.ID, []vocabSeed{
		{strPtr("食べる"), "たべる", "taberu", "To eat", "verb", "ごはんをたべます。"},
		{strPtr("飲む"), "のむ", "nomu", "To drink", "verb", "みずをのみます。"},
		{strPtr("見る"), "みる", "miru", "To see / watch", "verb", "テレビをみます。"},
		{strPtr("聞く"), "きく", "kiku", "To listen / ask", "verb", "おんがくをききます。"},
		{strPtr("話す"), "はなす", "hanasu", "To speak", "verb", "にほんごをはなします。"},
		{strPtr("書く"), "かく", "kaku", "To write", "verb", "てがみをかきます。"},
		{strPtr("読む"), "よむ", "yomu", "To read", "verb", "ほんをよみます。"},
		{strPtr("行く"), "いく", "iku", "To go", "verb", "がっこうへいきます。"},
		{strPtr("来る"), "くる", "kuru", "To come", "verb", "ともだちがきます。"},
		{strPtr("帰る"), "かえる", "kaeru", "To return home", "verb", "うちにかえります。"},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 5 — Basic Kanji
// ─────────────────────────────────────────────────────────────────────────────

func seedBasicKanji(database *gorm.DB, course models.Course) {
	sec := upsertSection(database, course.ID, models.Section{Title: "Basic Kanji", SortOrder: 6})

	m1 := upsertModule(database, sec.ID, models.Module{Title: "Nature Kanji", SortOrder: 1, PassThreshold: 90})
	upsertVocabItems(database, m1.ID, []vocabSeed{
		{strPtr("山"), "やま", "yama", "Mountain", "noun", "やまがたかいです。"},
		{strPtr("川"), "かわ", "kawa", "River", "noun", "かわでおよぎます。"},
		{strPtr("木"), "き", "ki", "Tree", "noun", "きがおおきいです。"},
		{strPtr("火"), "ひ", "hi", "Fire", "noun", "ひがあついです。"},
		{strPtr("水"), "みず", "mizu", "Water", "noun", "みずをのみます。"},
		{strPtr("土"), "つち", "tsuchi", "Soil / Earth", "noun", "つちがやわらかいです。"},
		{strPtr("空"), "そら", "sora", "Sky", "noun", "そらがあおいです。"},
		{strPtr("花"), "はな", "hana", "Flower", "noun", "はながきれいです。"},
	})

	m2 := upsertModule(database, sec.ID, models.Module{Title: "People & Body Kanji", SortOrder: 2, PassThreshold: 90})
	upsertVocabItems(database, m2.ID, []vocabSeed{
		{strPtr("人"), "ひと", "hito", "Person", "noun", "あのひとはだれですか？"},
		{strPtr("女"), "おんな", "onna", "Woman / Female", "noun", "おんなのひとです。"},
		{strPtr("男"), "おとこ", "otoko", "Man / Male", "noun", "おとこのこです。"},
		{strPtr("子"), "こ", "ko", "Child", "noun", "こどもがすきです。"},
		{strPtr("目"), "め", "me", "Eye", "noun", "めがおおきいです。"},
		{strPtr("耳"), "みみ", "mimi", "Ear", "noun", "みみがいたいです。"},
		{strPtr("口"), "くち", "kuchi", "Mouth", "noun", "くちをあけてください。"},
		{strPtr("手"), "て", "te", "Hand", "noun", "てをあらいます。"},
		{strPtr("足"), "あし", "ashi", "Foot / Leg", "noun", "あしがながいです。"},
	})

	m3 := upsertModule(database, sec.ID, models.Module{Title: "Place & Direction Kanji", SortOrder: 3, PassThreshold: 90})
	upsertVocabItems(database, m3.ID, []vocabSeed{
		{strPtr("上"), "うえ", "ue", "Above / Up", "noun/adj", "つくえのうえにあります。"},
		{strPtr("下"), "した", "shita", "Below / Down", "noun/adj", "いすのしたにあります。"},
		{strPtr("右"), "みぎ", "migi", "Right", "noun", "みぎにまがってください。"},
		{strPtr("左"), "ひだり", "hidari", "Left", "noun", "ひだりにまがってください。"},
		{strPtr("中"), "なか", "naka", "Inside / Middle", "noun", "はこのなかにあります。"},
		{strPtr("外"), "そと", "soto", "Outside", "noun", "そとはさむいです。"},
		{strPtr("前"), "まえ", "mae", "In front / Before", "noun", "えきのまえです。"},
		{strPtr("後"), "うしろ", "ushiro", "Behind / After", "noun", "うしろをみてください。"},
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Section 6 — Kotoba (Vocabulary with Kanji) loaded from JSON
// ─────────────────────────────────────────────────────────────────────────────

// jsonVocabItem mirrors the shape of each object in kotoba.json.
type jsonVocabItem struct {
	Kanji   string `json:"kanji"`
	Kana    string `json:"kana"`
	Romaji  string `json:"romaji"`
	Meaning string `json:"meaning"`
	POS     string `json:"pos"`
	Example string `json:"example"`
}

type jsonModule struct {
	Title         string          `json:"title"`
	SortOrder     int             `json:"sort_order"`
	PassThreshold int             `json:"pass_threshold"`
	Items         []jsonVocabItem `json:"items"`
}

type jsonSection struct {
	Section   string       `json:"section"`
	SortOrder int          `json:"sort_order"`
	Modules   []jsonModule `json:"modules"`
}

func seedKotobaFromJSON(database *gorm.DB, course models.Course) {
	// Locate data/ relative to this source file so it works from any cwd.
	_, filename, _, _ := runtime.Caller(0)
	dataDir := filepath.Join(filepath.Dir(filename), "data")

	files, err := filepath.Glob(filepath.Join(dataDir, "*.json"))
	if err != nil {
		log.Fatalf("seedKotobaFromJSON: glob: %v", err)
	}
	sort.Strings(files) // consistent alphabetical order

	for _, path := range files {
		log.Printf("  loading %s", filepath.Base(path))
		raw, err := os.ReadFile(path)
		if err != nil {
			log.Fatalf("seedKotobaFromJSON: read %s: %v", path, err)
		}

		var sections []jsonSection
		if err := json.Unmarshal(raw, &sections); err != nil {
			log.Fatalf("seedKotobaFromJSON: parse %s: %v", path, err)
		}

		for _, s := range sections {
			sec := upsertSection(database, course.ID, models.Section{
				Title:     s.Section,
				SortOrder: s.SortOrder,
			})

			for _, mod := range s.Modules {
				m := upsertModule(database, sec.ID, models.Module{
					Title:         mod.Title,
					SortOrder:     mod.SortOrder,
					PassThreshold: mod.PassThreshold,
				})

				seeds := make([]vocabSeed, 0, len(mod.Items))
				for _, item := range mod.Items {
					var kanji *string
					if item.Kanji != "" {
						k := item.Kanji
						kanji = &k
					}
					seeds = append(seeds, vocabSeed{
						Kanji:           kanji,
						Kana:            item.Kana,
						Romaji:          item.Romaji,
						EnglishMeaning:  item.Meaning,
						PartOfSpeech:    item.POS,
						ExampleSentence: item.Example,
					})
				}
				upsertVocabItems(database, m.ID, seeds)
			}
		}
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Paged vocab — data/json/vocab/vocab/{n3,n4,n5}/page_*.json
//
// Each page is a flat array of {kanji, reading, meaning_en, meaning_id}.
// Pages are folded into the existing JLPT N5/N4/N3 sections so the new
// vocabulary participates in the same progressive-unlock path as the
// hand-curated modules. One module per page is created, sorted after the
// curated modules (sort_order >= 100). Romaji is derived from the reading
// via KanaToRomaji since the source datasets do not provide it.
// ─────────────────────────────────────────────────────────────────────────────

type pageVocabItem struct {
	Kanji     string `json:"kanji"`
	Reading   string `json:"reading"`
	MeaningEN string `json:"meaning_en"`
	MeaningID string `json:"meaning_id"`
}

// pagedLevelSpec maps a directory name (n3/n4/n5) to the existing section
// title and the sort_order offset applied to its page-derived modules.
// premium marks sections locked behind the paid tier (N4/N3, not N5).
type pagedLevelSpec struct {
	dirName        string
	sectionTitle   string
	sectionSort    int
	moduleSortBase int
	premium        bool
}

func seedPagedVocab(database *gorm.DB, course models.Course) {
	_, filename, _, _ := runtime.Caller(0)
	dataDir := filepath.Join(filepath.Dir(filename), "data", "json", "vocab", "vocab")

	specs := []pagedLevelSpec{
		{"n5", "JLPT N5 Vocabulary (Kotoba)", 7, 100, false},
		{"n4", "JLPT N4 Vocabulary (Kotoba)", 8, 100, true},
		{"n3", "JLPT N3 Vocabulary (Kotoba)", 9, 100, true},
	}

	for _, spec := range specs {
		pattern := filepath.Join(dataDir, spec.dirName, "page_*.json")
		files, err := filepath.Glob(pattern)
		if err != nil {
			log.Printf("seedPagedVocab: glob %s: %v", pattern, err)
			continue
		}
		if len(files) == 0 {
			log.Printf("seedPagedVocab: no files under %s, skipping", spec.dirName)
			continue
		}

		sort.Strings(files)
		sec := upsertSection(database, course.ID, models.Section{
			Title:     spec.sectionTitle,
			SortOrder: spec.sectionSort,
			IsPremium: spec.premium,
		})

		for idx, path := range files {
			page := parsePageNumber(path)
			mod := upsertModule(database, sec.ID, models.Module{
				Title:         fmt.Sprintf("%s Vocab — Page %d", strings.ToUpper(spec.dirName), page),
				SortOrder:     spec.moduleSortBase + idx,
				PassThreshold: 90,
			})
			items := loadPageVocab(database, mod.ID, path)
			log.Printf("      %s: %d items", filepath.Base(path), items)
		}
	}
}

func loadPageVocab(database *gorm.DB, moduleID uuid.UUID, path string) int {
	raw, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("loadPageVocab: read %s: %v", path, err)
	}
	var rows []pageVocabItem
	if err := json.Unmarshal(raw, &rows); err != nil {
		log.Fatalf("loadPageVocab: parse %s: %v", path, err)
	}
	for _, row := range rows {
		var kanji *string
		if row.Kanji != "" {
			k := row.Kanji
			kanji = &k
		}
		var indo *string
		if row.MeaningID != "" {
			s := row.MeaningID
			indo = &s
		}
		upsertVocabItem(database, models.VocabItem{
			ModuleID:          moduleID,
			Kanji:             kanji,
			Kana:              row.Reading,
			Romaji:            KanaToRomaji(row.Reading),
			EnglishMeaning:    row.MeaningEN,
			IndonesianMeaning: indo,
		})
	}
	return len(rows)
}

// parsePageNumber extracts the integer suffix from a path such as
// "...\n5\page_12.json" → 12. Falls back to 0 on parse failure.
func parsePageNumber(path string) int {
	base := filepath.Base(path)
	base = strings.TrimSuffix(base, filepath.Ext(base))
	if i := strings.Index(base, "_"); i >= 0 {
		if n, err := strconv.Atoi(base[i+1:]); err == nil {
			return n
		}
	}
	return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// Day-files — data/json/day-*.json
//
// Each day file is a flat array of {kanji, reading|hiragana, meaning} where
// `meaning` is in Indonesian. There is no English gloss and no JLPT tag, so
// the day batches live in their own dedicated section, one module per day,
// so the existing gating engine drives a linear day-by-day unlock path.
// ─────────────────────────────────────────────────────────────────────────────

// dayVocabItem covers both observed shapes: {kanji, reading, meaning} and
// {kanji, hiragana, meaning}. Either key may be present; we prefer
// `reading` and fall back to `hiragana`.
type dayVocabItem struct {
	Kanji    string `json:"kanji"`
	Reading  string `json:"reading"`
	Hiragana string `json:"hiragana"`
	Meaning  string `json:"meaning"`
}

func seedDayFiles(database *gorm.DB, course models.Course) {
	_, filename, _, _ := runtime.Caller(0)
	dataDir := filepath.Join(filepath.Dir(filename), "data", "json")

	pattern := filepath.Join(dataDir, "day-*.json")
	files, err := filepath.Glob(pattern)
	if err != nil {
		log.Printf("seedDayFiles: glob %s: %v", pattern, err)
		return
	}
	if len(files) == 0 {
		return
	}

	// Sort by the numeric day embedded in the filename so modules unlock
	// in chronological order (day 29 → day 30 → …).
	sort.Slice(files, func(i, j int) bool {
		return extractDayNumber(files[i]) < extractDayNumber(files[j])
	})

	sec := upsertSection(database, course.ID, models.Section{
		Title:     "Daily Vocab (Day 29–59)",
		SortOrder: 100,
		IsPremium: true,
	})

	for idx, path := range files {
		day := extractDayNumber(path)
		mod := upsertModule(database, sec.ID, models.Module{
			Title:         fmt.Sprintf("Day %d", day),
			SortOrder:     idx + 1,
			PassThreshold: 90,
		})
		items := loadDayVocab(database, mod.ID, path)
		log.Printf("      %s: %d items", filepath.Base(path), items)
	}
}

func loadDayVocab(database *gorm.DB, moduleID uuid.UUID, path string) int {
	raw, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("loadDayVocab: read %s: %v", path, err)
	}
	var rows []dayVocabItem
	if err := json.Unmarshal(raw, &rows); err != nil {
		log.Fatalf("loadDayVocab: parse %s: %v", path, err)
	}
	for _, row := range rows {
		kana := row.Reading
		if kana == "" {
			kana = row.Hiragana
		}
		if kana == "" {
			// Nothing to key on; skip rather than crash on (module_id, kana) lookup.
			continue
		}
		var kanji *string
		if row.Kanji != "" {
			k := row.Kanji
			kanji = &k
		}
		var indo *string
		if row.Meaning != "" {
			s := row.Meaning
			indo = &s
		}
		upsertVocabItem(database, models.VocabItem{
			ModuleID:          moduleID,
			Kanji:             kanji,
			Kana:              kana,
			Romaji:            KanaToRomaji(kana),
			EnglishMeaning:    "",
			IndonesianMeaning: indo,
		})
	}
	return len(rows)
}

// extractDayNumber reads "...\day-50.json" → 50, returning 0 on failure.
func extractDayNumber(path string) int {
	base := filepath.Base(path)
	base = strings.TrimSuffix(base, filepath.Ext(base))
	if i := strings.Index(base, "-"); i >= 0 {
		if n, err := strconv.Atoi(base[i+1:]); err == nil {
			return n
		}
	}
	return 0
}

// ─────────────────────────────────────────────────────────────────────────────

func upsertCourse(database *gorm.DB, c models.Course) models.Course {
	var record models.Course
	database.Where("title = ?", c.Title).FirstOrCreate(&record, c)
	log.Printf("  course: %s (%s)", record.Title, record.ID)
	return record
}

func upsertSection(database *gorm.DB, courseID uuid.UUID, s models.Section) models.Section {
	s.CourseID = courseID
	var record models.Section
	database.Where("course_id = ? AND title = ?", courseID, s.Title).FirstOrCreate(&record, s)
	// Always keep sort_order and the premium flag up-to-date on re-runs.
	updates := map[string]any{}
	if record.SortOrder != s.SortOrder {
		updates["sort_order"] = s.SortOrder
		record.SortOrder = s.SortOrder
	}
	if record.IsPremium != s.IsPremium {
		updates["is_premium"] = s.IsPremium
		record.IsPremium = s.IsPremium
	}
	if len(updates) > 0 {
		database.Model(&record).Updates(updates)
	}
	log.Printf("    section: %s (%s)", record.Title, record.ID)
	return record
}

func upsertModule(database *gorm.DB, sectionID uuid.UUID, m models.Module) models.Module {
	m.SectionID = sectionID
	var record models.Module
	database.Where("section_id = ? AND title = ?", sectionID, m.Title).FirstOrCreate(&record, m)
	log.Printf("      module: %s (%s)", record.Title, record.ID)
	return record
}

type vocabSeed struct {
	Kanji           *string
	Kana            string
	Romaji          string
	EnglishMeaning  string
	PartOfSpeech    string
	ExampleSentence string
}

// upsertVocabItem inserts a fully-formed VocabItem if no row with the same
// (module_id, kana) already exists. Safe to call from any loader that
// populates fields the legacy vocabSeed struct does not carry (e.g. the
// Indonesian gloss for batch-imported vocab).
func upsertVocabItem(database *gorm.DB, item models.VocabItem) {
	database.Clauses(clause.OnConflict{DoNothing: true}).
		Where("module_id = ? AND kana = ?", item.ModuleID, item.Kana).
		FirstOrCreate(&item)
}

func upsertVocabItems(database *gorm.DB, moduleID uuid.UUID, items []vocabSeed) {
	for _, v := range items {
		upsertVocabItem(database, models.VocabItem{
			ModuleID:        moduleID,
			Kanji:           v.Kanji,
			Kana:            v.Kana,
			Romaji:          v.Romaji,
			EnglishMeaning:  v.EnglishMeaning,
			PartOfSpeech:    v.PartOfSpeech,
			ExampleSentence: v.ExampleSentence,
		})
	}
}
