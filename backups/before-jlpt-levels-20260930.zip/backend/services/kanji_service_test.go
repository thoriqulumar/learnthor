package services

import (
	"testing"

	"github.com/learnthor/backend/models"
)

func TestKanjiServiceListsAndSearchesBilingualCatalog(t *testing.T) {
	database := newTestDB(t)
	entries := []models.KanjiEntry{
		{SeedKey: "kanji:n5-day", Character: "日", JLPTLevel: "N5", SortOrder: 1, StrokeCount: 4, OnReadings: "ニチ|ジツ", KunReadings: "ひ|-び", EnglishMeaning: "day, sun", IndonesianMeaning: "hari, matahari", ExampleWords: "日本|今日", StrokeSVG: "/kanji/065e5.svg"},
		{SeedKey: "kanji:n3-cat", Character: "猫", JLPTLevel: "N3", SortOrder: 1, StrokeCount: 11, OnReadings: "ビョウ", KunReadings: "ねこ", EnglishMeaning: "cat", IndonesianMeaning: "kucing", StrokeSVG: "/kanji/0732b.svg"},
	}
	if err := database.Create(&entries).Error; err != nil {
		t.Fatal(err)
	}

	service := NewKanjiService(database)
	all, err := service.List("", "")
	if err != nil || len(all) != 2 || all[0].Character != "日" {
		t.Fatalf("unexpected list: %#v, %v", all, err)
	}
	results, err := service.List("N3", "kucing")
	if err != nil || len(results) != 1 || results[0].Character != "猫" {
		t.Fatalf("unexpected bilingual search: %#v, %v", results, err)
	}
	if len(results[0].KunReadings) != 1 || results[0].KunReadings[0] != "ねこ" {
		t.Fatalf("readings were not decoded: %#v", results[0].KunReadings)
	}
}
